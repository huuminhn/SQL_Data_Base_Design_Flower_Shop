-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mm_cpsc5910team03
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `order_info`
--

DROP TABLE IF EXISTS `order_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_info` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `order_num` int NOT NULL,
  `order_date` date NOT NULL,
  `order_type` varchar(45) NOT NULL,
  `order_status` varchar(45) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `cust_id` int NOT NULL,
  `payment_id` int NOT NULL,
  `service_id` int NOT NULL,
  `ship_id` int NOT NULL,
  `shipment_fee_id` int NOT NULL,
  PRIMARY KEY (`order_id`,`cust_id`,`payment_id`,`service_id`,`ship_id`),
  UNIQUE KEY `oderID_UNIQUE` (`order_id`),
  KEY `fk_order_info_payment_info1_idx` (`payment_id`),
  KEY `fk_order_info_event_service1_idx` (`service_id`),
  KEY `fk_order_info_shipping_info*1_idx` (`ship_id`),
  KEY `fk_order_info_shipment_fee1_idx` (`shipment_fee_id`),
  KEY `fk_order_info_cust_info1` (`cust_id`),
  CONSTRAINT `fk_order_info_cust_info1` FOREIGN KEY (`cust_id`) REFERENCES `cust_info` (`cust_id`),
  CONSTRAINT `fk_order_info_payment_info1` FOREIGN KEY (`payment_id`) REFERENCES `payment_detail` (`payment_id`),
  CONSTRAINT `fk_order_info_shipment_fee1` FOREIGN KEY (`shipment_fee_id`) REFERENCES `shipment_fee` (`shipment_fee_id`),
  CONSTRAINT `fk_order_info_shipping_info*1` FOREIGN KEY (`ship_id`) REFERENCES `shipping` (`ship_id`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_info`
--

LOCK TABLES `order_info` WRITE;
/*!40000 ALTER TABLE `order_info` DISABLE KEYS */;
INSERT INTO `order_info` VALUES (101,1100,'2017-10-10','delivery','Completed',14.39,1,10001,217,1,8),(102,1101,'2017-11-10','delivery','Completed',29.74,1,10002,217,2,8),(103,1102,'2017-12-10','delivery','Completed',42.99,1,10003,217,3,8),(104,1103,'2018-01-10','delivery','Completed',101.99,1,10004,217,4,8),(105,1104,'2018-02-10','delivery','Completed',150.99,1,10005,217,5,8),(106,1105,'2018-03-10','delivery','Completed',62.24,1,10006,217,6,8),(107,1106,'2018-04-10','delivery','Completed',14.39,1,10007,217,7,8),(108,1107,'2018-05-10','delivery','Completed',29.74,1,10008,217,8,8),(109,1108,'2020-02-22','event service','Completed',499.99,2,10009,201,9,1),(110,1109,'2019-04-11','delivery','Completed',34.99,3,10010,217,10,8),(111,1110,'2019-08-21','delivery','Completed',113.24,3,10011,217,11,8),(112,1111,'2019-12-25','delivery','Completed',314.98,3,10012,217,12,8),(113,1112,'2020-01-15','delivery','Completed',15.99,3,10013,217,13,8),(114,1113,'2019-12-16','event service','Completed',799.99,4,10014,202,14,8),(115,1114,'2018-07-07','delivery','Completed',29.74,5,10015,217,15,5),(116,1115,'2018-08-07','delivery','Completed',26.24,5,10016,217,16,5),(117,1116,'2018-09-07','delivery','Completed',122.39,5,10017,217,17,5),(118,1117,'2018-10-07','delivery','Completed',135.99,5,10018,217,18,5),(119,1118,'2019-12-25','delivery','Completed',70.54,6,10019,217,19,2),(120,1119,'2020-02-18','delivery','Completed',262.49,6,10020,217,20,2),(121,1120,'2019-09-12','delivery','Completed',13.59,7,10021,217,21,3),(122,1121,'2020-01-05','delivery','Completed',122.39,7,10022,217,22,3),(123,1122,'2020-02-08','delivery','Completed',15.99,7,10023,217,23,3),(124,1123,'2022-08-20','delivery','Completed',115.59,8,10024,217,24,4),(125,1124,'2021-10-20','delivery','Completed',34.99,8,10025,217,25,4),(126,1125,'2020-12-20','delivery','Completed',13.59,8,10026,217,26,4),(127,1126,'2020-02-20','delivery','Completed',15.99,8,10027,217,27,4),(128,1127,'2019-07-21','event service','Completed',2799.99,9,10028,203,28,4),(129,1128,'2020-02-22','event service','Completed',399.99,10,10029,204,29,2),(130,1129,'2019-05-20','delivery','Completed',113.24,11,10030,217,30,2),(131,1130,'2020-01-17','delivery','Completed',13.59,11,10031,217,31,2),(132,1131,'2020-01-16','delivery','Completed',115.59,12,10032,217,32,1),(133,1132,'2020-02-10','delivery','Completed',15.99,12,10033,217,33,1),(134,1133,'2020-02-23','delivery','Completed',38.69,12,10034,217,34,1),(135,1134,'2019-11-19','event service','Completed',1099.99,13,10035,205,35,6),(136,1135,'2020-02-22','event service','Completed',699.99,14,10036,206,36,6),(137,1136,'2020-02-10','event service','Completed',499.99,15,10037,207,37,6),(138,1137,'2020-01-28','event service','Completed',3499.99,16,10038,208,38,1),(139,1138,'2022-08-11','delivery','Completed',82.99,17,10039,217,39,4),(140,1139,'2021-10-11','delivery','Completed',74.69,17,10040,217,40,4),(141,1140,'2020-12-11','delivery','Completed',70.54,17,10041,217,41,4),(142,1141,'2020-02-11','delivery','Completed',349.98,17,10042,217,42,4),(143,1142,'2019-06-25','delivery','Completed',15.99,18,10043,217,43,4),(144,1143,'2019-08-25','delivery','Completed',14.39,18,10044,217,44,4),(145,1144,'2019-10-25','delivery','Completed',15.99,18,10045,217,45,4),(146,1145,'2019-12-25','delivery','Completed',82.99,18,10046,217,46,4),(147,1146,'2020-01-27','delivery','Completed',297.48,18,10047,217,47,4),(148,1147,'2020-01-23','event service','Completed',499.99,19,10048,209,48,1),(149,1148,'2020-02-07','event service','Completed',699.99,20,10049,210,49,1),(150,1149,'2019-11-02','delivery','Completed',13.59,21,10050,217,50,1),(151,1150,'2019-11-03','delivery','Completed',15.99,21,10051,217,51,1),(152,1151,'2019-11-04','delivery','Completed',13.59,21,10052,217,52,1),(153,1152,'2020-02-05','delivery','Completed',199.99,22,10053,211,53,1),(154,1153,'2019-03-28','delivery','Completed',42.99,23,10054,217,54,1),(155,1154,'2019-05-12','delivery','Completed',38.69,23,10055,217,55,1),(156,1155,'2020-02-09','delivery','Completed',42.99,23,10056,217,56,1),(157,1156,'2019-04-10','event service','Completed',3499.99,24,10057,212,57,7),(158,1157,'2019-11-03','delivery','Completed',150.99,25,10058,217,58,2),(159,1158,'2019-12-03','delivery','Completed',113.24,25,10059,217,59,2),(160,1159,'2020-01-03','delivery','Completed',135.89,25,10060,217,60,2),(161,1160,'2020-02-03','delivery','Completed',150.99,25,10061,217,61,2),(162,1161,'2019-12-25','delivery','Completed',70.54,26,10062,217,62,3),(163,1162,'2020-02-09','delivery','Completed',82.99,26,10063,217,63,3),(164,1163,'2020-02-10','event service','Completed',499.99,27,10064,213,64,3),(165,1164,'2020-01-26','event service','Completed',1999.99,28,10065,214,65,8),(166,1165,'2020-02-02','event service','Completed',3499.99,29,10066,215,66,8),(167,1166,'2020-02-23','event service','Completed',599.99,30,10067,216,67,8);
/*!40000 ALTER TABLE `order_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-29  0:10:01
