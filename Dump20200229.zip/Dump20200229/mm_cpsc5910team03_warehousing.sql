-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mm_cpsc5910team03
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `warehousing`
--

DROP TABLE IF EXISTS `warehousing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehousing` (
  `warehousing_id` int NOT NULL AUTO_INCREMENT,
  `warehousing_date` date DEFAULT NULL COMMENT 'Date the product is delivered from supplier, or a future date when it will be delivered.',
  `warehousing_amt` int NOT NULL,
  `warehousing_price` decimal(10,2) DEFAULT NULL,
  `delivered` tinyint DEFAULT NULL COMMENT 'Boolean indicating whether the product is delivered. If false, it means supplier missed delivery date or it will be delivered in a future date.',
  `quality_check` varchar(45) DEFAULT NULL,
  `product_id` int NOT NULL,
  `supplier_id` int NOT NULL,
  PRIMARY KEY (`warehousing_id`,`product_id`,`supplier_id`),
  UNIQUE KEY `inventory_id_UNIQUE` (`warehousing_id`),
  KEY `fk_inventory_info_product_info1_idx` (`product_id`),
  KEY `fk_inventory_info_supplier_info1_idx` (`supplier_id`),
  CONSTRAINT `fk_inventory_info_product_info1` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  CONSTRAINT `fk_inventory_info_supplier_info1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehousing`
--

LOCK TABLES `warehousing` WRITE;
/*!40000 ALTER TABLE `warehousing` DISABLE KEYS */;
INSERT INTO `warehousing` VALUES (101,'0000-00-00',100,5.99,1,'8',21,1001),(102,'0000-00-00',200,4.99,1,'5',21,1002),(103,'0000-00-00',150,8.99,1,'9',21,1003),(104,'0000-00-00',40,5.75,1,'8',21,1004),(105,'0000-00-00',300,6.54,1,'9',22,1005),(106,'0000-00-00',50,3.87,1,'7',22,1006),(107,'0000-00-00',60,5.99,1,'5',23,1007),(108,'0000-00-00',90,2.50,1,'6',24,1008),(109,'0000-00-00',28,4.35,1,'9',24,1009),(110,'0000-00-00',28,3.75,1,'5',24,1010),(111,'0000-00-00',28,2.35,1,'6',24,1011),(112,'0000-00-00',28,3.26,1,'7',24,1012),(113,'0000-00-00',28,7.33,1,'8',24,1013),(114,'0000-00-00',28,2.45,1,'6',24,1014),(115,'0000-00-00',28,4.22,1,'5',25,1015),(116,'0000-00-00',28,1.99,1,'4',26,1016),(117,'0000-00-00',28,5.99,1,'7',26,1017),(118,'0000-00-00',28,5.99,1,'8',27,1018),(119,'0000-00-00',28,5.99,1,'7',27,1019),(120,'0000-00-00',28,3.75,1,'7',27,1020),(121,'0000-00-00',28,4.50,1,'8',27,1001),(122,'0000-00-00',28,4.00,1,'6',27,1002),(123,'0000-00-00',5,5.99,1,'8',28,1003),(124,'0000-00-00',8,4.99,1,'5',28,1004),(125,'0000-00-00',4,8.99,1,'9',28,1005),(126,'0000-00-00',2,5.75,1,'8',29,1006),(127,'0000-00-00',7,6.54,1,'9',29,1007),(128,'0000-00-00',5,3.87,1,'7',30,1008),(129,'0000-00-00',8,5.99,1,'5',30,1009),(130,'0000-00-00',3,2.50,1,'6',31,1010),(131,'0000-00-00',7,4.35,1,'9',31,1011),(132,'0000-00-00',9,3.75,1,'5',32,1012),(133,'0000-00-00',3,2.35,1,'6',32,1013),(134,'0000-00-00',5,3.26,1,'7',32,1014),(135,'0000-00-00',7,7.33,1,'8',33,1015),(136,'0000-00-00',5,2.45,1,'6',33,1016),(137,'0000-00-00',3,4.22,1,'5',33,1017),(138,'0000-00-00',5,1.99,1,'4',34,1018),(139,'0000-00-00',9,5.99,1,'7',34,1019),(140,'0000-00-00',5,5.99,1,'8',35,1020),(141,'0000-00-00',1,5.99,1,'7',35,1001),(142,'0000-00-00',5,3.75,1,'7',36,1002),(143,'0000-00-00',7,4.50,1,'8',36,1003),(144,'0000-00-00',5,4.00,1,'6',37,1004),(145,'0000-00-00',3,5.00,1,'9',37,1005);
/*!40000 ALTER TABLE `warehousing` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-29  0:10:03
