-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mm_cpsc5910team03
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `shipping`
--

DROP TABLE IF EXISTS `shipping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipping` (
  `ship_id` int NOT NULL AUTO_INCREMENT,
  `tracking_num` varchar(40) NOT NULL,
  `street` varchar(100) NOT NULL,
  `street(line2)` varchar(45) DEFAULT NULL,
  `city` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `zip_code` varchar(20) NOT NULL,
  `ship_company` varchar(60) NOT NULL,
  `ship_status` varchar(45) NOT NULL,
  `est_arrive_time` date NOT NULL,
  `recipient_f_name` varchar(30) NOT NULL,
  `recipient_l_name` varchar(30) NOT NULL,
  `recipient_phone` varchar(20) NOT NULL,
  PRIMARY KEY (`ship_id`),
  UNIQUE KEY `shipping_id_UNIQUE` (`ship_id`),
  UNIQUE KEY `tracking_num_UNIQUE` (`tracking_num`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping`
--

LOCK TABLES `shipping` WRITE;
/*!40000 ALTER TABLE `shipping` DISABLE KEYS */;
INSERT INTO `shipping` VALUES (1,'NC001PF015053','6649 N Blue Gum St','','Seattle','WA','98122','FedEx','Shipped','2018-05-11','Lois','Walker','810-292-9388'),(2,'NC002PF015054','4 B Blue Ridge Blvd','','Bellevue','WA','98006','DHL','Deliveried','2020-02-23','Brenda','Robinson','856-636-8749'),(3,'NC003PF015055','8 W Cerritos Ave #54','','Seattle','WA','98122','UPS','En Route','2020-01-17','Joe','Robinson','907-385-4412'),(4,'NC001PF015054','639 Main St','','Seattle','WA','98122','USP','Not yet been shipped','2019-12-18','Diane','Evans','513-570-1893'),(5,'NC002PF015055','34 Center St','','Seattle','WA','98101','FedEx','Deliveried','2018-10-09','Benjamin','Russell','419-503-2484'),(6,'NC003PF015056','3 Mcauley Dr','','Sammamish','WA','98029','DHL','En Route','2020-02-19','Minh','Nguyen','206-854-1995'),(7,'NC001PF015055','7 Eads St','','Kirkland','WA','98033','FedEx','Shipped','2020-02-09','Nancy','Baker','605-414-2147'),(8,'NC002PF015056','7 W Jackson Blvd','','Redmond','WA','98052','UPS','En Route','2020-02-20','Carol','Murphy','410-655-8723'),(9,'NC003PF015057','5 Boston Ave #88','','Redmond','WA','98052','FedEx','Deliveried','2019-07-21','Britney','Spear','206-839-2943'),(10,'NC001PF015056','228 Runamuck Pl #2808','','Sammamish','WA','98029','DHL','Shipped','2020-02-28','Diana','Peterson','310-498-5651'),(11,'NC002PF015057','2371 Jerrold Ave','','Sammamish','WA','98029','UPS','Deliveried','2020-01-24','Ralph','Flores','440-780-8425'),(12,'NC003PF015058','37275 St Rt 17m M','','Bellevue','WA','98006','FedEx','Shipped','2020-02-23','Jack','Alexander','602-277-4385'),(13,'NC001PF015057','25 E 75th St #69','','Seattle','WA','98102','DHL','Not yet been shipped','2019-11-26','Melissa','King','931-313-9635'),(14,'NC002PF015058','98 Connecticut Ave Nw','','Seattle','WA','98102','FedEx','Deliveried','2020-02-27','Dwayne','Johnson','212-349-2954'),(15,'NC003PF015059','56 E Morehead St','','Seattle','WA','98102','USP','En Route','2020-02-14','Cheryl','Scott','313-288-7937'),(16,'NC001PF015058','73 State Road 434 E','','Bellevue','WA','98006','DHL','Deliveried','2020-02-12','Paula','Diaz','815-828-2147'),(17,'NC002PF015059','69734 E Carrillo St','','Redmond','WA','98052','UPS','Not yet been shipped','2020-02-16','Son','Tung','206-104-4353'),(18,'NC003PF015060','322 New Horizon Blvd','','Redmond','WA','98052','UPS','Shipped','2020-02-06','Theresa','Lee','972-303-9197'),(19,'NC001PF015059','1 State Route 27','','Bellevue','WA','98006','USP','Not yet been shipped','2020-01-29','Julia','Scott','732-658-3154'),(20,'NC002PF015060','394 Manchester Blvd','','Bellevue','WA','98006','FedEx','Shipped','2020-02-15','Thomas','Lewis','715-662-6764'),(21,'NC003PF015061','6 S 33rd St','','Bellevue','WA','98006','UPS','Deliveried','2019-11-27','Carol','Edwards','913-388-2079'),(22,'NC001PF015060','6 Greenleaf Ave','','Bellevue','WA','98006','USP','En Route','2020-02-14','Matthew','Turner','410-669-1642'),(23,'NC002PF015061','618 W Yakima Ave','','Bellevue','WA','98006','USP','Shipped','2020-02-14','Adam','Lavine','202-405-3390'),(24,'NC003PF015062','74 S Westgate St','','Seattle','WA','98112','UPS','Deliveried','2019-04-18','Ruby','Rogers','810-374-9840'),(25,'NC001PF015061','3273 State St','','Sammamish','WA','98029','FedEx','Deliveried','2020-02-19','Carolyn','Hayes','856-264-4130'),(26,'NC002PF015062','1 Central Ave','','Kirkland','WA','98033','USP','Not yet been shipped','2020-02-09','Anne','Russell','907-921-2010'),(27,'NC003PF015063','86 Nw 66th St #8673','','Kirkland','WA','98033','FedEx','Deliveried','2020-03-10','Clark','Ken','206-350-4938'),(28,'NC001PF015062','2 Cedar Ave #84','','Seattle','WA','98122','USP','Not yet been shipped','2020-01-29','Roger','Roberts','419-800-6759'),(29,'NC002PF015063','90991 Thorburn Ave','','Seattle','WA','98122','DHL','En Route','2020-02-09','Maria','Walker','773-924-8565'),(30,'NC003PF015064','386 9th Ave N','','Seattle','WA','98122','DHL','Shipped','2020-02-25','Brenda','Butler','480-814-8284'),(31,'NC003PF015065','4252 N Washington Ave #9','','Seattle','WA','98122','DHL','','0000-00-00','Christiane','Eschberger','404-505-4445'),(32,'NC003PF015066','42754 S Ash Ave','','Seattle','WA','98122','DHL','','0000-00-00','Goldie','Schirpke','973-412-2995'),(33,'NC003PF015067','703 Beville Rd','','Seattle','WA','98122','DHL','','0000-00-00','Loreta','Timenez','208-252-4552'),(34,'NC003PF015068','5 Harrison Rd','','Seattle','WA','98122','DHL','','0000-00-00','Fabiola','Hauenstein','415-411-1775'),(35,'NC003PF015069','73 Southern Blvd','','Seattle','WA','98122','DHL','','0000-00-00','Amie','Perigo','508-942-4186'),(36,'NC003PF015070','189 Village Park Rd','','Seattle','WA','98122','DHL','','0000-00-00','Raina','Brachle','248-357-8718'),(37,'NC003PF015071','6 Middlegate Rd #106','','Seattle','WA','98122','DHL','','0000-00-00','Erinn','Canlas','920-353-6377'),(38,'NC003PF015072','1128 Delaware St','','Seattle','WA','98122','DHL','','0000-00-00','Cherry','Lietz','410-665-4903'),(39,'NC003PF015073','577 Parade St','','Seattle','WA','98122','DHL','','0000-00-00','Kattie','Vonasek','719-669-1664'),(40,'NC003PF015074','70 Mechanic St','','Seattle','WA','98122','DHL','','0000-00-00','Lilli','Scriven','419-588-8719'),(41,'NC003PF015075','4379 Highway 116','','Seattle','WA','98122','DHL','','0000-00-00','Whitley','Tomasulo','301-998-9644'),(42,'NC003PF015076','55 Hawthorne Blvd','','Seattle','WA','98122','DHL','','0000-00-00','Barbra','Adkin','508-855-9887'),(43,'NC003PF015077','7116 Western Ave','','Seattle','WA','98122','DHL','','0000-00-00','Hermila','Thyberg','703-483-1970'),(44,'NC003PF015078','2026 N Plankinton Ave #3','','Seattle','WA','98122','DHL','','0000-00-00','Jesusita','Flister','410-678-2473'),(45,'NC003PF015079','99586 Main St','','Seattle','WA','98122','DHL','','0000-00-00','Caitlin','Julia','512-223-4791'),(46,'NC003PF015080','8739 Hudson St','','Seattle','WA','98122','DHL','','0000-00-00','Roosevelt','Hoffis','623-461-8551'),(47,'NC003PF015081','383 Gunderman Rd #197','','Seattle','WA','98122','DHL','','0000-00-00','Helaine','Halter','419-571-5920'),(48,'NC003PF015082','4441 Point Term Mkt','','Seattle','WA','98122','DHL','','0000-00-00','Lorean','Martabano','206-311-4137'),(49,'NC003PF015083','2972 Lafayette Ave','','Redmond','WA','98052','DHL','','0000-00-00','France','Buzick','513-617-2362'),(50,'NC003PF015084','2140 Diamond Blvd','','Redmond','WA','98052','DHL','','0000-00-00','Justine','Ferrario','812-368-1511'),(51,'NC003PF015085','93 Redmond Rd #492','','Redmond','WA','98052','DHL','','0000-00-00','Adelina','Nabours','847-353-2156'),(52,'NC003PF015086','3989 Portage Tr','','Seattle','WA','98122','DHL','','0000-00-00','Derick','Dhamer','718-232-2337'),(53,'NC003PF015087','1 Midway Rd','','Seattle','WA','98122','DHL','','0000-00-00','Jerry','Dallen','407-446-4358'),(54,'NC003PF015088','77132 Coon Rapids Blvd Nw','','Seattle','WA','98122','DHL','','0000-00-00','Leota','Ragel','734-561-6170'),(55,'NC003PF015089','755 Harbor Way','','Seattle','WA','98122','DHL','','0000-00-00','Jutta','Amyot','936-751-7961'),(56,'NC003PF015090','87 Sierra Rd','','Seattle','WA','98122','DHL','','0000-00-00','Aja','Gehrett','973-482-2430'),(57,'NC003PF015091','7667 S Hulen St #42','','Seattle','WA','98122','DHL','','0000-00-00','Kirk','Herritt','201-693-3967'),(58,'NC003PF015092','75684 S Withlapopka Dr #32','','Seattle','WA','98122','DHL','','0000-00-00','Leonora','Mauson','305-988-4162'),(59,'NC003PF015093','5 Elmwood Park Blvd','','Kirkland','WA','98033','DHL','','0000-00-00','Winfred','Brucato','931-553-9774'),(60,'NC003PF015094','23 Palo Alto Sq','','Kirkland','WA','98033','DHL','','0000-00-00','Tarra','Nachor','714-771-3880'),(61,'NC003PF015095','38062 E Main St','','Kirkland','WA','98033','DHL','','0000-00-00','Corinne','Loder','847-633-3216'),(62,'NC003PF015096','3958 S Dupont Hwy #7','','Kirkland','WA','98033','DHL','','0000-00-00','Dulce','Labreche','215-888-3304'),(63,'NC003PF015097','560 Civic Center Dr','','Kirkland','WA','98033','DHL','','0000-00-00','Kate','Keneipp','973-654-1561'),(64,'NC003PF015098','3270 Dequindre Rd','','Kirkland','WA','98033','DHL','','0000-00-00','Kaitlyn','Ogg','814-865-8113'),(65,'NC003PF015099','1 Garfield Ave #7','','Bellevue','WA','98006','DHL','','0000-00-00','Sherita','Saras','801-293-9853'),(66,'NC003PF015100','9122 Carpenter Ave','','Bellevue','WA','98006','DHL','','0000-00-00','Lashawnda','Stuer','910-922-3672'),(67,'NC003PF015101','48 Lenox St','','Bellevue','WA','98006','DHL','','0000-00-00','Ernest','Syrop','336-370-5333');
/*!40000 ALTER TABLE `shipping` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-29  0:10:03
