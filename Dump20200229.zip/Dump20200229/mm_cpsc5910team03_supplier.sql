-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mm_cpsc5910team03
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier` (
  `supplier_id` int NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(60) NOT NULL,
  `supplier_address` varchar(100) DEFAULT NULL,
  `contact_person` varchar(60) DEFAULT NULL,
  `phone_num` varchar(20) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `web_url` varchar(200) DEFAULT NULL,
  `bank_acct_num` char(16) DEFAULT NULL,
  `bank_info` varchar(100) DEFAULT NULL,
  `license_info` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`supplier_id`),
  UNIQUE KEY `supplier_id_UNIQUE` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1021 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1001,'Rosy Rose','63517 Dupont St','Husser','419-417-4674','sharee_maile@aol.com','http://www.kenjeterstoreequipmentinc.com','548926458','BoA','ahd73jf'),(1002,'ButterCup Blossoms','5 E Truman Rd','Onofrio','619-727-3892','cordelia_storment@aol.com','http://www.potterbrendajcpa.com','573837533','WellsFargo','jflwsh39'),(1003,'Tuesday\'s Farms','251 Park Ave #979','Jurney','203-918-3939','mollie_mcdoniel@yahoo.com','http://www.bairdkurtzdobson.com','657829262','Chase','sjfgk2h3'),(1004,'Flower Me Up','43496 Commercial Dr #29','Heimann','201-969-7063','brett.mccullan@mccullan.com','http://www.minorcynthiaaesq.com','265926593','BoA','hflgfl238'),(1005,'Boss Blossoms','2184 Worth St','Wenzinger','330-566-8898','teddy_pedrozo@aol.com','http://www.soloverobertaesq.com','837659626','Chase','jvkvhe2'),(1006,'Hi Hi Bye','50126 N Plankinton Ave','Angalich','201-772-4377','tasia_andreason@yahoo.com','http://www.markiiimportsinc.com','165936490','BoA','wa82jf'),(1007,'Thompson, John Randolph Jr','38773 Gravois Ave','Ohms','616-568-4113','hubert@walthall.org','http://www.whitesigndivctrlequipco.com','356814037','BoA','ahd73jf'),(1008,'Five Star','16452 Greenwich St','Leinenbach','601-637-5479','arthur.farrow@yahoo.com','http://www.mmstorefixturescoinc.com','313517287','WellsFargo','jflwsh39'),(1009,'Moskowitz, Barry S','40 Cambridge Ave','Suell','901-869-4314','vberlanga@berlanga.com','http://www.judahcasterwheelco.com','270220538','Chase','sjfgk2h3'),(1010,'Jackson Millwork Co','20113 4th Ave E','Myricks','303-997-7760','billye_miro@cox.net','http://www.galaxyinternationalinc.com','226923789','BoA','hflgfl238'),(1011,'Knwz Newsradio','6 Ridgewood Center Dr','Swayze','901-739-5892','glenna_slayton@cox.net','http://www.sigmacorpofamerica.com','183627039','Chase','jvkvhe2'),(1012,'Ac Supply Co','469 Outwater Ln','Castros','626-293-7678','mitzie_hudnall@yahoo.com','http://www.sowardanneesq.com','140330290','BoA','wa82jf'),(1013,'Milford Enterprises Inc','62 Monroe St','Greenbush','773-857-2231','bernardine_rodefer@yahoo.com','http://www.osbornemichellemesq.com','97033540','BoA','ahd73jf'),(1014,'Mosocco, Ronald A','3338 A Lockport Pl #6','Lapage','718-728-5051','staci_schmaltz@aol.com','http://www.studentsinfreeentrprsnatl.com','53736791','WellsFargo','jflwsh39'),(1015,'Tri Co','9 Hwy','Claucherty','509-847-3352','nichelle_meteer@meteer.com','http://www.johnsonrobertmesq.com','10440041','Chase','sjfgk2h3'),(1016,'Cowan & Kelly flower planting','8284 Hart St','Villanueva','410-429-4888','jrhoden@yahoo.com','http://www.delcharroapartments.com','285670787','BoA','hflgfl238'),(1017,'Adam gardern','5 Washington St #1','Perruzza','973-605-6492','ettie.hoopengardner@hotmail.com','http://www.legalsearchinc.com','76153456','Chase','jvkvhe2'),(1018,'Mcrae, James L','8 S Haven St','Wildfong','562-719-7922','eden_jayson@yahoo.com','http://www.servicesupplycoinc.com','119450206','BoA','wa82jf'),(1019,'Tri M Inc','9 Front St','Galam','732-617-5310','lynelle_auber@gmail.com','http://www.sameshimadouglasjesq.com','162746955','BoA','ahd73jf'),(1020,'International flower Inc','1933 Packer Ave #2','Lipkin','973-491-8723','merissa.tomblin@gmail.com','http://www.thompsonjohnrandolphjr.com','604370567','WellsFargo','jflwsh39');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-29  0:10:03
