-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mm_cpsc5910team03
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `supplier_review`
--

DROP TABLE IF EXISTS `supplier_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_review` (
  `supplier_review_id` int NOT NULL AUTO_INCREMENT,
  `review` varchar(500) NOT NULL,
  `score` int NOT NULL,
  `supplier_id` int NOT NULL,
  `product_id` int NOT NULL,
  PRIMARY KEY (`supplier_review_id`,`supplier_id`,`product_id`),
  UNIQUE KEY `supplier_review_id_UNIQUE` (`supplier_review_id`),
  KEY `fk_supplier_review_supplier_info1_idx` (`supplier_id`),
  KEY `fk_supplier_review_product_info1_idx` (`product_id`),
  CONSTRAINT `fk_supplier_review_product_info1` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  CONSTRAINT `fk_supplier_review_supplier_info1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_review`
--

LOCK TABLES `supplier_review` WRITE;
/*!40000 ALTER TABLE `supplier_review` DISABLE KEYS */;
INSERT INTO `supplier_review` VALUES (1,'Horrible experience',3,1001,21),(2,'Payment in time',3,1002,21),(3,'Nice to do Business again',6,1003,21),(4,'Nice to do Business again',5,1004,21),(5,'Nice to do Business again',4,1005,22),(6,'Glad to work with your shop',7,1006,22),(7,'Glad to work with your shop',10,1007,23),(8,'Payment in time',10,1008,24),(9,'Nice to do Business again',10,1009,24),(10,'Payment in time',8,1010,24),(11,'Payment in time',3,1011,24),(12,'Payment in time',9,1012,24),(13,'Payment in time',9,1013,24),(14,'Payment in time',8,1014,24),(15,'Nice to do Business again',4,1015,25),(16,'As Usual',8,1016,26),(17,'Glad to work with your shop',10,1017,26),(18,'Glad to work with your shop',10,1018,27),(19,'Horrible experience',1,1019,27),(20,'Long term collaboration',9,1020,27),(21,'Payment in time',5,1001,27),(22,'Payment in time',4,1002,27),(23,'Horrible experience',1,1003,28),(24,'Payment in time',6,1004,28),(25,'Payment in time',6,1005,28),(26,'Long term collaboration',9,1006,29),(27,'As Usual',6,1007,29),(28,'Long term collaboration',7,1008,30),(29,'Glad to work with your shop',10,1009,30),(30,'Long term collaboration',8,1010,31),(31,'Payment in time',4,1011,31),(32,'Horrible experience',1,1012,32),(33,'Glad to work with your shop',10,1013,32),(34,'Long term collaboration',8,1014,32),(35,'Payment in time',6,1015,33),(36,'Payment in time',6,1016,33),(37,'Payment in time',3,1017,33),(38,'Horrible experience',2,1018,34),(39,'Glad to work with your shop',8,1019,34),(40,'Payment in time',2,1020,35),(41,'As Usual',8,1001,35),(42,'Payment in time',2,1002,36),(43,'Nice to do Business again',7,1003,36),(44,'As Usual',6,1004,37),(45,'Payment in time',4,1005,37);
/*!40000 ALTER TABLE `supplier_review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-29  0:10:01
