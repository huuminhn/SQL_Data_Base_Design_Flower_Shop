-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mm_cpsc5910team03
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cust_contact_info`
--

DROP TABLE IF EXISTS `cust_contact_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cust_contact_info` (
  `cust_contact_id` int NOT NULL AUTO_INCREMENT,
  `phone_num` varchar(20) NOT NULL,
  `email` varchar(60) NOT NULL,
  `cust_id` int NOT NULL,
  PRIMARY KEY (`cust_contact_id`,`cust_id`),
  UNIQUE KEY `cust_contact_id_UNIQUE` (`cust_contact_id`),
  KEY `fk_cust_contact_info_cust_info1` (`cust_id`),
  CONSTRAINT `fk_cust_contact_info_cust_info1` FOREIGN KEY (`cust_id`) REFERENCES `cust_info` (`cust_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust_contact_info`
--

LOCK TABLES `cust_contact_info` WRITE;
/*!40000 ALTER TABLE `cust_contact_info` DISABLE KEYS */;
INSERT INTO `cust_contact_info` VALUES (1,'504-621-8927','lois.walker@hotmail.com',1),(2,'810-292-9388','lois.walker@hotmail.com',1),(3,'856-636-8749','brenda.robinson@gmail.com',2),(4,'907-385-4412','joe.robinson@gmail.com',3),(5,'513-570-1893','diane.evans@yahoo.com',4),(6,'419-503-2484','benjamin.russell@charter.net',5),(7,'773-573-6914','benjamin.russell@charter.net',5),(8,'408-752-3500','patrick.bailey@aol.com',6),(9,'605-414-2147','nancy.baker@bp.com',7),(10,'410-655-8723','carol.murphy@gmail.com',8),(11,'215-874-1229','carol.murphy@gmail.com',8),(12,'631-335-3414','frances.young@gmail.com',9),(13,'310-498-5651','diana.peterson@hotmail.com',10),(14,'440-780-8425','ralph.flores@yahoo.com',11),(15,'956-537-6195','ralph.flores@yahoo.com',11),(16,'602-277-4385','jack.alexander@gmail.com',12),(17,'931-313-9635','melissa.king@comcast.net',13),(18,'414-661-9598','wayne.watson@gmail.com',14),(19,'313-288-7937','cheryl.scott@gmail.com',15),(20,'815-828-2147','paula.diaz@gmail.com',16),(21,'610-545-3615','paula.diaz@gmail.com',16),(22,'408-540-1785','joshua.stewart@yahoo.ca',17),(23,'972-303-9197','theresa.lee@gmail.com',18),(24,'518-966-7987','theresa.lee@gmail.com',18),(25,'732-658-3154','julia.scott@apple.com',19),(26,'715-662-6764','thomas.lewis@gmail.com',20),(27,'913-388-2079','carol.edwards@msn.com',21),(28,'410-669-1642','matthew.turner@gmail.com',22),(29,'212-582-4976','joan.stewart@yahoo.com',23),(30,'504-845-1427','joan.stewart@yahoo.com',23),(31,'810-374-9840','ruby.rogers@gmail.com',24),(32,'856-264-4130','carolyn.hayes@hotmail.co.uk',25),(33,'907-921-2010','anne.russell@ibm.com',26),(34,'513-549-4561','daniel.cooper@yahoo.com',27),(35,'419-800-6759','roger.roberts@gmail.com',28),(36,'773-924-8565','maria.walker@microsoft.com',29),(37,'480-814-8284','brenda.butler@gmail.com',30);
/*!40000 ALTER TABLE `cust_contact_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-29  0:10:02
