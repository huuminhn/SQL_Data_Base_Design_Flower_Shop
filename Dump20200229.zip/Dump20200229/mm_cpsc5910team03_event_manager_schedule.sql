-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mm_cpsc5910team03
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event_manager_schedule`
--

DROP TABLE IF EXISTS `event_manager_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_manager_schedule` (
  `event_manager_schedule_id` int NOT NULL AUTO_INCREMENT,
  `scheduled_time` date NOT NULL,
  `status` varchar(30) NOT NULL,
  `event_manager_id` int NOT NULL,
  PRIMARY KEY (`event_manager_schedule_id`,`event_manager_id`),
  UNIQUE KEY `event_manager_schedule_id_UNIQUE` (`event_manager_schedule_id`),
  KEY `fk_event_manager_schedule_event_manager_info1_idx` (`event_manager_id`),
  CONSTRAINT `fk_event_manager_schedule_event_manager_info1` FOREIGN KEY (`event_manager_id`) REFERENCES `event_manager` (`manager_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_manager_schedule`
--

LOCK TABLES `event_manager_schedule` WRITE;
/*!40000 ALTER TABLE `event_manager_schedule` DISABLE KEYS */;
INSERT INTO `event_manager_schedule` VALUES (1,'2019-03-10','Available',1),(2,'2020-02-14','Not Available',3),(3,'2019-08-20','Available',2),(4,'2019-06-04','Available',4),(5,'2019-06-26','Available',6),(6,'2020-02-08','Available',7),(7,'2019-08-04','Not Available',2),(8,'2019-11-10','Available',3),(9,'2019-07-30','Available',5),(10,'2019-03-15','Not Available',1),(11,'2019-04-22','Available',6),(12,'2019-02-25','Not Available',7),(13,'2019-05-04','Not Available',4),(14,'2020-02-14','Available',7),(15,'2020-02-14','Available',8),(16,'2020-02-14','Available',9),(17,'2020-02-14','Available',12),(18,'2020-02-14','Available',13),(19,'2020-02-14','Available',1),(20,'2021-02-14','Available',18),(21,'2021-02-14','Available',2),(22,'2021-02-14','Available',3),(23,'2021-02-14','Available',8),(24,'2021-02-14','Available',9);
/*!40000 ALTER TABLE `event_manager_schedule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-29  0:10:04
