-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mm_cpsc5910team03
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cust_address`
--

DROP TABLE IF EXISTS `cust_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cust_address` (
  `cust_address_id` int NOT NULL AUTO_INCREMENT,
  `street` varchar(50) NOT NULL,
  `street(line2)` varchar(45) DEFAULT NULL,
  `city` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `zip_code` varchar(20) NOT NULL,
  `cust_id` int NOT NULL,
  PRIMARY KEY (`cust_address_id`,`cust_id`),
  UNIQUE KEY `cust_address_id_UNIQUE` (`cust_address_id`),
  KEY `fk_cust_address_cust_info1` (`cust_id`),
  CONSTRAINT `fk_cust_address_cust_info1` FOREIGN KEY (`cust_id`) REFERENCES `cust_info` (`cust_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust_address`
--

LOCK TABLES `cust_address` WRITE;
/*!40000 ALTER TABLE `cust_address` DISABLE KEYS */;
INSERT INTO `cust_address` VALUES (1,'6649 N Blue Gum St','','Seattle','WA','98122',1),(2,'4 B Blue Ridge Blvd','','Bellevue','WA','98006',2),(3,'8 W Cerritos Ave #54','','Seattle','WA','98122',3),(4,'639 Main St','','Seattle','WA','98122',4),(5,'34 Center St','','Seattle','WA','98101',5),(6,'3 Mcauley Dr','','Sammamish','WA','98029',6),(7,'7 Eads St','','Kirkland','WA','98033',7),(8,'7 W Jackson Blvd','','Redmond','WA','98052',8),(9,'5 Boston Ave #88','','Redmond','WA','98052',9),(10,'228 Runamuck Pl #2808','','Sammamish','WA','98029',10),(11,'2371 Jerrold Ave','','Sammamish','WA','98029',11),(12,'37275 St Rt 17m M','','Bellevue','WA','98006',12),(13,'25 E 75th St #69','','Seattle','WA','98102',13),(14,'98 Connecticut Ave Nw','','Seattle','WA','98102',14),(15,'56 E Morehead St','','Seattle','WA','98102',15),(16,'73 State Road 434 E','','Bellevue','WA','98006',16),(17,'69734 E Carrillo St','','Redmond','WA','98052',17),(18,'322 New Horizon Blvd','','Redmond','WA','98052',18),(19,'1 State Route 27','','Bellevue','WA','98006',19),(20,'394 Manchester Blvd','','Bellevue','WA','98006',20),(21,'6 S 33rd St','','Bellevue','WA','98006',21),(22,'6 Greenleaf Ave','','Bellevue','WA','98006',22),(23,'618 W Yakima Ave','','Bellevue','WA','98006',23),(24,'74 S Westgate St','','Seattle','WA','98112',24),(25,'3273 State St','','Sammamish','WA','98029',25),(26,'1 Central Ave','','Kirkland','WA','98033',26),(27,'86 Nw 66th St #8673','','Kirkland','WA','98033',27),(28,'2 Cedar Ave #84','','Seattle','WA','98122',28),(29,'90991 Thorburn Ave','','Seattle','WA','98122',29),(30,'386 9th Ave N','','Seattle','WA','98122',30);
/*!40000 ALTER TABLE `cust_address` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-29  0:10:02
