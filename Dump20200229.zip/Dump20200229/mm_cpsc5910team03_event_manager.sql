-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mm_cpsc5910team03
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event_manager`
--

DROP TABLE IF EXISTS `event_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_manager` (
  `manager_id` int NOT NULL AUTO_INCREMENT,
  `f_name` varchar(30) NOT NULL,
  `l_name` varchar(30) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `email` varchar(60) NOT NULL,
  `specialty` varchar(50) NOT NULL COMMENT 'Specialty in holding one event, e.g.: Birthday, Wedding…',
  PRIMARY KEY (`manager_id`),
  UNIQUE KEY `manager_id_UNIQUE` (`manager_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_manager`
--

LOCK TABLES `event_manager` WRITE;
/*!40000 ALTER TABLE `event_manager` DISABLE KEYS */;
INSERT INTO `event_manager` VALUES (1,'Barbara','Wicks','431-796-2043','bwicks0@issuu.com','Birthday'),(2,'Billy','Crosser','556-908-5296','bcrosser1@columbia.edu','Wedding'),(3,'Morris','Reynalds','337-000-2332','mreynalds2@oaic.gov.au','Wedding'),(4,'Haslett','Sarath','811-146-0326','hsarath3@scientificamerican.com','Graduation'),(5,'Elwin','Belly','438-209-3715','ebelly4@51.la','Party'),(6,'Christie','Seal','881-371-9046','cseal5@uiuc.edu','Birthday'),(7,'Godiva','Cleyburn','904-237-9313','gcleyburn6@cloudflare.com','Birthday'),(8,'Eugene','Perez','308-646-6219','eugene.perez@exxonmobil.com','Party'),(9,'Deborah','Smith','314-731-7135','deborah.smith@yahoo.com','Party'),(10,'Janice','Parker','308-827-9016','janice.parker@yahoo.com','Wedding'),(11,'Rebecca','Stewart','240-513-8668','rebecca.stewart@gmail.com','Wedding'),(12,'Phillip','White','480-946-9780','phillip.white@gmail.com','Birthday'),(13,'Jose','Hill','219-624-3708','jose.hill@hotmail.com','Birthday'),(14,'Harold','Nelson','423-974-2755','harold.nelson@gmail.com','Wedding'),(15,'Nicole','Ward','225-968-5952','nicole.ward@yahoo.com','Wedding'),(16,'Theresa','Murphy','406-961-7340','theresa.murphy@gmail.com','Birthday'),(17,'Tammy','Young','217-856-6752','tammy.young@comcast.net','Birthday'),(18,'Jimmy','Lee','390-288-4902','jlee@gmail.com','Wedding'),(19,'null','null','123-456-789','null@gmail.com','null');
/*!40000 ALTER TABLE `event_manager` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-29  0:10:03
