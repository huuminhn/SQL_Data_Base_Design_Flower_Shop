-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mm_cpsc5910team03
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cust_info`
--

DROP TABLE IF EXISTS `cust_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cust_info` (
  `cust_id` int NOT NULL AUTO_INCREMENT,
  `f_name` varchar(30) NOT NULL,
  `l_name` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `user_name` varchar(45) NOT NULL,
  `ps_word` varchar(45) NOT NULL,
  `member_level` varchar(30) NOT NULL,
  `mem_since` date NOT NULL,
  `points` int NOT NULL,
  `last_login_time` date NOT NULL,
  `last_order_time` date DEFAULT NULL,
  PRIMARY KEY (`cust_id`),
  UNIQUE KEY `custID_UNIQUE` (`cust_id`),
  UNIQUE KEY `user_name_UNIQUE` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust_info`
--

LOCK TABLES `cust_info` WRITE;
/*!40000 ALTER TABLE `cust_info` DISABLE KEYS */;
INSERT INTO `cust_info` VALUES (1,'Lois','Walker','1967-12-01','lhwalker','DCa}.T}X:v?NP','1','2017-01-05',78,'2019-06-13','2018-05-10'),(2,'Brenda','Robinson','1969-02-10','bsrobinson','TCoj#Zg;SQ~o','5','2016-11-24',431,'2020-02-22','2020-02-06'),(3,'Joe','Robinson','1983-09-14','jwrobinson','GO4$J8MiEh[A','4','2016-08-03',356,'2020-01-15','2020-01-15'),(4,'Diane','Evans','1973-12-22','dievans','0gGRtp1HfL<r5','2','2016-02-07',146,'2019-12-16','2019-12-16'),(5,'Benjamin','Russell','1994-11-14','brrussell','Rd<Y8cp!@R;*%F','3','2016-01-24',279,'2019-11-17','2018-10-07'),(6,'Patrick','Bailey','1991-08-31','pfbailey','K7&5aY/*','6','2015-01-19',563,'2020-02-18','2020-02-18'),(7,'Nancy','Baker','1982-07-29','ntbaker','xJdKlAcYQhT_BE#','7','2016-09-14',680,'2020-02-08','2020-02-08'),(8,'Carol','Murphy','1985-01-04','cvmurphy','Uc+VG%vuZU<k','8','2015-07-25',750,'2020-02-20','2020-02-20'),(9,'Frances','Young','1978-12-11','fbyoung','K}^USc0l7[A','4','2018-09-10',380,'2019-10-21','2019-07-21'),(10,'Diana','Peterson','1964-08-15','dtpeterson','3o8>v&tYxjyEAo','7','2014-02-17',630,'2020-02-22','2020-02-22'),(11,'Ralph','Flores','1983-11-14','rlflores','7tPLrSr}qTqj','3','2016-08-18',280,'2020-01-17','2020-01-17'),(12,'Jack','Alexander','1989-11-09','jcalexander','9L*-O1U.9mSUSh','8','2014-03-06',750,'2020-02-23','2020-02-23'),(13,'Melissa','King','1991-08-12','mqking','FE5i<e-Y}[4f78','2','2018-11-24',150,'2019-11-19','2019-11-19'),(14,'Wayne','Watson','1993-11-10','wgwatson','wM4J{]&j-eGc','9','2017-07-19',890,'2020-02-22','2020-02-22'),(15,'Cheryl','Scott','1996-04-14','coscott','Vbb+~2N|_yR','5','2017-05-01',460,'2020-02-10','2020-02-10'),(16,'Paula','Diaz','1988-10-31','pgdiaz','3Kg55luU','6','2017-08-20',570,'2020-01-28','2020-01-28'),(17,'Joshua','Stewart','1989-05-11','jtstewart','K?vi9BBznj','1','2020-01-12',80,'2020-02-11','2020-02-11'),(18,'Theresa','Lee','1979-03-22','tglee','JS#hN&Xij%QEr','8','2015-01-19',720,'2020-01-27','2020-01-27'),(19,'Julia','Scott','1982-11-06','jsscott','r.:Q7c^Tpb','4','2016-09-30',380,'2020-01-23','2020-01-23'),(20,'Thomas','Lewis','1976-05-30','tqlewis','y;OJd_Oa#4g|!G','2','2018-06-07',175,'2020-02-07','2020-02-07'),(21,'Carol','Edwards','1991-05-04','cjedwards','wi>v-a9gt','4','2016-04-25',360,'2019-11-04','2019-11-04'),(22,'Matthew','Turner','1992-12-25','mlturner','I>tL>d[|lZdi_|^','6','2016-08-23',590,'2020-02-05','2020-02-05'),(23,'Joan','Stewart','1984-10-28','jcstewart','u+CtpZ~gyR*>','8','2014-08-30',730,'2020-02-09','2020-02-09'),(24,'Ruby','Rogers','1984-01-19','rrrogers','t>#P@D9s<:9V','2','2017-06-21',180,'2019-09-07','2019-04-10'),(25,'Carolyn','Hayes','1995-08-27','cvhayes','NY!Y2sw.[_v-Q9{','4','2016-02-05',390,'2020-02-03','2020-02-03'),(26,'Anne','Russell','1994-10-08','alrussell','c8Nk&Y^~Vz!2','5','2017-08-20',457,'2020-02-09','2020-02-09'),(27,'Daniel','Cooper','1969-10-30','dkcooper','d8p{Pwx2fsW0-Z','1','2019-06-09',60,'2020-02-10','2020-02-10'),(28,'Roger','Roberts','1984-11-06','rlroberts','41:C_0ik|Jb0iTO','3','2017-02-22',285,'2020-01-26','2020-01-26'),(29,'Maria','Walker','1987-12-30','mwwalker','cw?%U}s{?','7','2015-04-13',690,'2020-02-02','2020-02-02'),(30,'Brenda','Butler','1990-02-19','bmbutler','u+CtpZ~gyR*>','9','2016-01-09',900,'2020-02-23','2020-02-23');
/*!40000 ALTER TABLE `cust_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-29  0:10:02
