-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mm_cpsc5910team03
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event_service`
--

DROP TABLE IF EXISTS `event_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_service` (
  `service_id` int NOT NULL AUTO_INCREMENT,
  `service_type` varchar(45) NOT NULL,
  `service_time` date NOT NULL,
  `street` varchar(60) NOT NULL,
  `street(line 2)` varchar(60) DEFAULT NULL,
  `city` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `zip_code` varchar(20) NOT NULL,
  `service_status` varchar(45) NOT NULL,
  `manager_id` int NOT NULL,
  PRIMARY KEY (`service_id`,`manager_id`),
  UNIQUE KEY `service_id_UNIQUE` (`service_id`),
  KEY `fk_event_service_event_manager_info1_idx` (`manager_id`),
  CONSTRAINT `fk_event_service_event_manager_info1` FOREIGN KEY (`manager_id`) REFERENCES `event_manager` (`manager_id`)
) ENGINE=InnoDB AUTO_INCREMENT=218 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_service`
--

LOCK TABLES `event_service` WRITE;
/*!40000 ALTER TABLE `event_service` DISABLE KEYS */;
INSERT INTO `event_service` VALUES (201,'Party','2020-02-14','4 B Blue Ridge Blvd','','Bellevue','WA','98006','completed',3),(202,'Party','2019-12-25','639 Main St','','Seattle','WA','98122','completed',5),(203,'Wedding','2019-07-30','5 Boston Ave #88','','Redmond','WA','98052','completed',10),(204,'Birthaday','2020-04-09','228 Runamuck Pl #2808','','Sammamish','WA','98029','not completed',1),(205,'Party','2019-12-24','25 E 75th St #69','','Seattle','WA','98102','completed',5),(206,'Birthaday','2020-03-22','98 Connecticut Ave Nw','','Seattle','WA','98102','not completed',12),(207,'Party','2020-02-14','56 E Morehead St','','Seattle','WA','98102','completed',14),(208,'Wedding','2020-02-14','73 State Road 434 E','','Bellevue','WA','98006','completed',15),(209,'Party','2020-02-14','1 State Route 27','','Bellevue','WA','98006','completed',2),(210,'Birthaday','2020-05-07','394 Manchester Blvd','','Bellevue','WA','98006','not completed',6),(211,'Birthaday','2020-04-25','6 Greenleaf Ave','','Bellevue','WA','98006','not completed',7),(212,'Wedding','2019-04-10','74 S Westgate St','','Seattle','WA','98112','completed',10),(213,'Party','2020-02-14','86 Nw 66th St #8673','','Kirkland','WA','98033','completed',10),(214,'Wedding','2020-02-14','2 Cedar Ave #84','','Seattle','WA','98122','completed',11),(215,'Wedding','2020-03-31','90991 Thorburn Ave','','Seattle','WA','98122','not completed',10),(216,'Graduation','2020-06-23','386 9th Ave N','','Seattle','WA','98122','not completed',4),(217,'Delivery','2020-01-01','not applied','','Greater Seattle Area','WA','98000','not applied',19);
/*!40000 ALTER TABLE `event_service` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-29  0:10:01
