-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mm_cpsc5910team03
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `payment_detail`
--

DROP TABLE IF EXISTS `payment_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_detail` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `payment_mtd` varchar(60) NOT NULL,
  `name_on_card` varchar(50) NOT NULL,
  `card_num` char(16) NOT NULL,
  `scurity_code` varchar(4) DEFAULT NULL,
  `exp_date` date DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `street` varchar(60) NOT NULL,
  `street(line 2)` varchar(45) DEFAULT NULL,
  `city` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `zip_code` varchar(20) NOT NULL,
  `cust_id` int NOT NULL,
  PRIMARY KEY (`payment_id`,`cust_id`),
  UNIQUE KEY `payment_id_UNIQUE` (`payment_id`),
  KEY `fk_payment_info_cust_info1_idx` (`cust_id`),
  CONSTRAINT `fk_payment_info_cust_info1` FOREIGN KEY (`cust_id`) REFERENCES `cust_info` (`cust_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10068 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_detail`
--

LOCK TABLES `payment_detail` WRITE;
/*!40000 ALTER TABLE `payment_detail` DISABLE KEYS */;
INSERT INTO `payment_detail` VALUES (10001,'Credit','Lois Walker','4.56E+15','789','0000-00-00','3456','6649 N Blue Gum St','','Seattle','WA','98122',1),(10002,'Credit','Lois Walker','4.56E+15','789','0000-00-00','3456','6650 N Blue Gum St','','Seattle','WA','98123',1),(10003,'Credit','Lois Walker','4.56E+15','789','0000-00-00','3456','6651 N Blue Gum St','','Seattle','WA','98124',1),(10004,'Credit','Lois Walker','4.56E+15','789','0000-00-00','3456','6652 N Blue Gum St','','Seattle','WA','98125',1),(10005,'Credit','Lois Walker','4.56E+15','789','0000-00-00','3456','6653 N Blue Gum St','','Seattle','WA','98126',1),(10006,'Credit','Lois Walker','4.56E+15','789','0000-00-00','3456','6654 N Blue Gum St','','Seattle','WA','98127',1),(10007,'Credit','Lois Walker','4.56E+15','789','0000-00-00','3456','6655 N Blue Gum St','','Seattle','WA','98128',1),(10008,'Credit','Lois Walker','4.56E+15','789','0000-00-00','3456','6655 N Blue Gum St','','Seattle','WA','98128',1),(10009,'Debit','Brenda Robinson','4.44E+15','464','0000-00-00','4565','4 B Blue Ridge Blvd','','Bellevue','WA','98006',2),(10010,'Credit','Joe Robinson','4.01E+15','463','0000-00-00','8976','8 W Cerritos Ave #54','','Seattle','WA','98122',3),(10011,'Credit','Joe Robinson','4.01E+15','463','0000-00-00','8976','8 W Cerritos Ave #54','','Seattle','WA','98122',3),(10012,'Credit','Joe Robinson','4.01E+15','463','0000-00-00','8976','8 W Cerritos Ave #54','','Seattle','WA','98122',3),(10013,'Credit','Joe Robinson','4.01E+15','463','0000-00-00','8976','8 W Cerritos Ave #54','','Seattle','WA','98122',3),(10014,'Debit','Diane Evans','4.59E+15','342','0000-00-00','2325','8 W Cerritos Ave #54','','Seattle','WA','98122',4),(10015,'Credit','Benjanmin Russell','4.52E+15','452','0000-00-00','5432','639 Main St','','Seattle','WA','98122',5),(10016,'Credit','Benjanmin Russell','4.52E+15','452','0000-00-00','5432','34 Center St','','Seattle','WA','98101',5),(10017,'Debit','Benjanmin Russell','4.52E+15','452','0000-00-00','5432','34 Center St','','Seattle','WA','98101',5),(10018,'Debit','Benjanmin Russell','4.52E+15','452','0000-00-00','5432','34 Center St','','Seattle','WA','98101',5),(10019,'Credit','Patrick Bailey','4.05E+15','342','0000-00-00','5467','3 Mcauley Dr','','Sammamish','WA','98029',6),(10020,'Credit','Patrick Bailey','4.05E+15','342','0000-00-00','5467','3 Mcauley Dr','','Sammamish','WA','98029',6),(10021,'Credit','Nancy Baker','4.14E+15','675','0000-00-00','3543','3 Mcauley Dr','','Sammamish','WA','98029',7),(10022,'Credit','Nancy Baker','4.14E+15','675','0000-00-00','3543','7 Eads St','','Kirkland','WA','98033',7),(10023,'Debit','Nancy Baker','4.14E+15','675','0000-00-00','3543','7 Eads St','','Kirkland','WA','98033',7),(10024,'Debit','Carol Murphy','4.51E+15','567','0000-00-00','3262','7 Eads St','','Kirkland','WA','98033',8),(10025,'Debit','Carol Murphy','4.51E+15','567','0000-00-00','3262','7 W Jackson Blvd','','Redmond','WA','98052',8),(10026,'Credit','Carol Murphy','4.51E+15','567','0000-00-00','3262','7 W Jackson Blvd','','Redmond','WA','98052',8),(10027,'Credit','Carol Murphy','4.51E+15','567','0000-00-00','3262','7 W Jackson Blvd','','Redmond','WA','98052',8),(10028,'Credit','Frances Young','4.00E+15','634','0000-00-00','3225','7 W Jackson Blvd','','Redmond','WA','98052',9),(10029,'Debit','Diana Peterson','4.40E+15','578','0000-00-00','2345','5 Boston Ave #88','','Redmond','WA','98052',10),(10030,'Credit','Raph Flores','4.07E+15','204','0000-00-00','2242','228 Runamuck Pl #2808','','Sammamish','WA','98029',11),(10031,'Debit','Raph Flores','4.07E+15','204','0000-00-00','2242','2371 Jerrold Ave','','Sammamish','WA','98029',11),(10032,'Debit','Jack Alexander','4.56E+15','405','0000-00-00','2446','2371 Jerrold Ave','','Sammamish','WA','98029',12),(10033,'Debit','Jack Alexander','4.56E+15','405','0000-00-00','2446','37275 St Rt 17m M','','Bellevue','WA','98006',12),(10034,'Credit','Jack Alexander','4.56E+15','405','0000-00-00','2446','37275 St Rt 17m M','','Bellevue','WA','98006',12),(10035,'Credit','Melissa King','4.38E+15','456','0000-00-00','2436','37275 St Rt 17m M','','Bellevue','WA','98006',13),(10036,'Debit','Wayne Watson','4.81E+15','504','0000-00-00','2634','25 E 75th St #69','','Seattle','WA','98102',14),(10037,'Credit','Cheryl Scott','4.16E+15','205','0000-00-00','4673','98 Connecticut Ave Nw','','Seattle','WA','98102',15),(10038,'Credit','Paula Diaz','4.55E+15','406','0000-00-00','2343','56 E Morehead St','','Seattle','WA','98102',16),(10039,'Credit','Joshua Stewart','4.17E+15','504','0000-00-00','6364','73 State Road 434 E','','Bellevue','WA','98006',17),(10040,'Credit','Joshua Stewart','4.17E+15','504','0000-00-00','3456','69734 E Carrillo St','','Redmond','WA','98052',17),(10041,'Debit','Joshua Stewart','4.17E+15','504','0000-00-00','3456','69734 E Carrillo St','','Redmond','WA','98052',17),(10042,'Debit','Joshua Stewart','4.17E+15','504','0000-00-00','3456','69734 E Carrillo St','','Redmond','WA','98052',17),(10043,'Debit','Theresa Lee','4.05E+15','547','0000-00-00','5363','69734 E Carrillo St','','Redmond','WA','98052',18),(10044,'Credit','Theresa Lee','4.05E+15','547','0000-00-00','5363','322 New Horizon Blvd','','Redmond','WA','98052',18),(10045,'Credit','Theresa Lee','4.05E+15','547','0000-00-00','5363','322 New Horizon Blvd','','Redmond','WA','98052',18),(10046,'Debit','Theresa Lee','4.05E+15','547','0000-00-00','5363','322 New Horizon Blvd','','Redmond','WA','98052',18),(10047,'Credit','Theresa Lee','4.05E+15','547','0000-00-00','5363','322 New Horizon Blvd','','Redmond','WA','98052',18),(10048,'Debit','Julia Scott','4.52E+15','895','0000-00-00','3452','322 New Horizon Blvd','','Redmond','WA','98052',19),(10049,'Credit','Thomas Lewis','4.07E+15','194','0000-00-00','4663','1 State Route 27','','Bellevue','WA','98006',20),(10050,'Debit','Carol Edwards','4.56E+15','105','0000-00-00','3245','394 Manchester Blvd','','Bellevue','WA','98006',21),(10051,'Debit','Carol Edwards','4.56E+15','105','0000-00-00','3245','6 S 33rd St','','Bellevue','WA','98006',21),(10052,'Debit','Carol Edwards','4.56E+15','105','0000-00-00','3245','6 S 33rd St','','Bellevue','WA','98006',21),(10053,'Credit','Matthew Turner','4.07E+15','204','0000-00-00','3452','6 S 33rd St','','Bellevue','WA','98006',22),(10054,'Credit','Joan Stewart','4.17E+15','890','0000-00-00','8967','6 Greenleaf Ave','','Bellevue','WA','98006',23),(10055,'Debit','Joan Stewart','4.17E+15','890','0000-00-00','8967','618 W Yakima Ave','','Bellevue','WA','98006',23),(10056,'Debit','Joan Stewart','4.17E+15','890','0000-00-00','8967','618 W Yakima Ave','','Bellevue','WA','98006',23),(10057,'Credit','Ruby Rogers','4.17E+15','948','0000-00-00','6453','618 W Yakima Ave','','Bellevue','WA','98006',24),(10058,'Debit','Carolyn Hayes','4.07E+15','493','0000-00-00','4562','74 S Westgate St','','Seattle','WA','98112',25),(10059,'Debit','Carolyn Hayes','4.07E+15','493','0000-00-00','4562','3273 State St','','Sammamish','WA','98029',25),(10060,'Credit','Carolyn Hayes','4.07E+15','493','0000-00-00','4562','3273 State St','','Sammamish','WA','98029',25),(10061,'Debit','Carolyn Hayes','4.07E+15','493','0000-00-00','4562','3273 State St','','Sammamish','WA','98029',25),(10062,'Credit','Anne Russell','4.82E+15','503','0000-00-00','4623','3273 State St','','Sammamish','WA','98029',26),(10063,'Debit','Anne Russell','4.82E+15','503','0000-00-00','4623','1 Central Ave','','Kirkland','WA','98033',26),(10064,'Credit','Daniel Cooper','4.07E+15','458','0000-00-00','2536','1 Central Ave','','Kirkland','WA','98033',27),(10065,'Debit','Roger Roberts','4.55E+15','395','0000-00-00','6685','2 Cedar Ave #84','','Seattle','WA','98122',28),(10066,'Credit','Maria Walker','4.56E+15','503','0000-00-00','3456','90991 Thorburn Ave','','Seattle','WA','98122',29),(10067,'Debit','Brenda Butler','4.54E+15','650','0000-00-00','6688','386 9th Ave N','','Seattle','WA','98122',30);
/*!40000 ALTER TABLE `payment_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-29  0:10:02
