-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mm_cpsc5910team03
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cust_review`
--

DROP TABLE IF EXISTS `cust_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cust_review` (
  `cust_review_id` int NOT NULL AUTO_INCREMENT,
  `review` varchar(500) DEFAULT NULL,
  `score` int DEFAULT NULL,
  `product_id` int NOT NULL,
  `cust_id` int NOT NULL,
  PRIMARY KEY (`cust_review_id`,`product_id`,`cust_id`),
  UNIQUE KEY `cust_review_id_UNIQUE` (`cust_review_id`),
  KEY `fk_cust_review_product_info1_idx` (`product_id`),
  KEY `fk_cust_review_cust_info1_idx` (`cust_id`),
  CONSTRAINT `fk_cust_review_cust_info1` FOREIGN KEY (`cust_id`) REFERENCES `cust_info` (`cust_id`),
  CONSTRAINT `fk_cust_review_product_info1` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust_review`
--

LOCK TABLES `cust_review` WRITE;
/*!40000 ALTER TABLE `cust_review` DISABLE KEYS */;
INSERT INTO `cust_review` VALUES (1,'The flowers were beautiful! Will order again from here!',5,21,1),(2,'The flowers were beautiful! Will order again from here!',5,22,1),(3,'The flowers were beautiful! Will order again from here!',5,23,1),(4,'The flowers were beautiful! Will order again from here!',5,24,1),(5,'The flowers were beautiful! Will order again from here!',4,25,1),(6,'The flowers were beautiful! Will order again from here!',4,26,1),(7,'The flowers were beautiful! Will order again from here!',5,21,1),(8,'The flowers were beautiful! Will order again from here!',5,22,1),(9,'Beautiful arrangement of flowers!',5,35,2),(10,'Good service',4,22,3),(11,'Good service',4,25,3),(12,'Good service',4,27,3),(13,'Good service',4,21,3),(14,'I was impressed how timely the delivery was. My daughter loved the bouquet! Thanks',5,36,4),(15,'Gorgeous arrangement and above and beyond delivery service considering the bad weather we were having.',5,22,5),(16,'Gorgeous arrangement and above and beyond delivery service considering the bad weather we were having.',4,22,5),(17,'Gorgeous arrangement and above and beyond delivery service considering the bad weather we were having.',5,24,5),(18,'Gorgeous arrangement and above and beyond delivery service considering the bad weather we were having.',5,24,5),(19,'Gorgeous flower arrangements and excellent service!! Many thanks!',5,26,6),(20,'Gorgeous flower arrangements and excellent service!! Many thanks!',5,27,6),(21,'We love the service you guys give thank you very much',5,21,7),(22,'We love the service you guys give thank you very much',4,24,7),(23,'We love the service you guys give thank you very much',5,21,7),(24,'The flowers arrangement are beautiful. Easy company to work with',5,24,8),(25,'The flowers arrangement are beautiful. Easy company to work with',4,22,8),(26,'The flowers arrangement are beautiful. Easy company to work with',5,21,8),(27,'The flowers arrangement are beautiful. Easy company to work with',5,21,8),(28,'I got your email and the flower arrangement is lovely and the lady that delivered them was very nice thank you',5,32,9),(29,'',0,29,10),(30,'Beautiful arngements and amazing customer service.',5,25,11),(31,'Beautiful arngements and amazing customer service.',5,21,11),(32,'The floral arrangements have been the prettiest I have ever seen.',5,24,12),(33,'The floral arrangements have been the prettiest I have ever seen.',5,21,12),(34,'The floral arrangements have been the prettiest I have ever seen.',4,23,12),(35,'Nice floral arrangements',4,37,13),(36,'',0,30,14),(37,'Beautiful flowers and they lasted for quite some time. Great service.',5,35,15),(38,'I received a floral arrangement from my husband for out 37th wedding anniversary. The flowers perfectly arranged and very colourful. Great job.',5,33,16),(39,'Very happy with the order I made. It was well worth the cost - a very beautiful arrangement was delivered. thank you!!',5,26,17),(40,'Very happy with the order I made. It was well worth the cost - a very beautiful arrangement was delivered. thank you!!',5,26,17),(41,'Very happy with the order I made. It was well worth the cost - a very beautiful arrangement was delivered. thank you!!',5,26,17),(42,'Very happy with the order I made. It was well worth the cost - a very beautiful arrangement was delivered. thank you!!',5,27,17),(43,'Thank you for your quality service.',4,21,18),(44,'Thank you for your quality service.',4,21,18),(45,'Thank you for your quality service.',4,21,18),(46,'Thank you for your quality service.',4,26,18),(47,'Thank you for your quality service.',5,27,18),(48,'I want to say how happy and impressed I am with the excellent service I recieved and the beautiful arrangement that was delivered.',5,35,19),(49,'',0,30,20),(50,'Beautiful arrangement as always.',4,27,21),(51,'Beautiful arrangement as always.',4,26,21),(52,'Beautiful arrangement as always.',4,27,21),(53,'',0,28,22),(54,'The flowers were very beautiful and amazing thank you so much very exciting',5,23,23),(55,'The flowers were very beautiful and amazing thank you so much very exciting',5,23,23),(56,'The flowers were very beautiful and amazing thank you so much very exciting',5,24,23),(57,'Excellent service, from start to finish, I could not have been more pleased.',5,33,24),(58,'I received an arrangement from your shop that was beautiful. I then needed 4 arrangements for a celebration of life so I ordered from your shop and again they were beautiful.',5,24,25),(59,'I received an arrangement from your shop that was beautiful. I then needed 4 arrangements for a celebration of life so I ordered from your shop and again they were beautiful.',5,25,25),(60,'I received an arrangement from your shop that was beautiful. I then needed 4 arrangements for a celebration of life so I ordered from your shop and again they were beautiful.',4,25,25),(61,'I received an arrangement from your shop that was beautiful. I then needed 4 arrangements for a celebration of life so I ordered from your shop and again they were beautiful.',5,22,25),(62,'We were happy to receive two beautiful arrangements for my B D plus a balloon. Made my day. Flowers doing great. thank you.',5,22,26),(63,'We were happy to receive two beautiful arrangements for my B D plus a balloon. Made my day. Flowers doing great. thank you.',5,22,26),(64,'Although the order was quickly put together, the flowers were in rough shape when delivered, and not worth the price of bouquet, will most likely not use again.',5,35,27),(65,'Very good, fast service, beautiful flowers',5,31,28),(66,'',0,33,29),(67,'',0,34,30);
/*!40000 ALTER TABLE `cust_review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-29  0:10:02
